"""
SecureChain DMS - AI Service (SIH26190)
-----------------------------------------
Standalone FastAPI microservice that performs OCR extraction (PaddleOCR)
and automatic legal-document classification for the Ministry of Home
Affairs blockchain-anchored Document Management System.

Endpoint:
    POST /api/v1/ai/analyze-document

Run:
    uvicorn main:app --host 0.0.0.0 --port 8000
"""

from __future__ import annotations

import io
import logging
import re
from contextlib import asynccontextmanager
from typing import Dict, List, Optional, Tuple

import numpy as np
from fastapi import FastAPI, File, HTTPException, UploadFile, status
from fastapi.responses import JSONResponse
from pdf2image import convert_from_bytes
from PIL import Image
from pydantic import BaseModel, Field

# --------------------------------------------------------------------------
# Logging
# --------------------------------------------------------------------------
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
)
logger = logging.getLogger("securechain.ai-service")

# --------------------------------------------------------------------------
# Global OCR engine (initialised once on startup to avoid cold starts)
# --------------------------------------------------------------------------
OCR_ENGINE = None  # populated in lifespan()

ALLOWED_CONTENT_TYPES = {
    "application/pdf": "pdf",
    "image/jpeg": "image",
    "image/jpg": "image",
    "image/png": "image",
}

MAX_FILE_SIZE_BYTES = 25 * 1024 * 1024  # 25 MB safety cap
MAX_PDF_PAGES = 15  # cap OCR pass for very large scanned dossiers


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Initialise the PaddleOCR model exactly once for the process lifetime."""
    global OCR_ENGINE
    logger.info("Initialising PaddleOCR engine (this happens once)...")
    try:
        from paddleocr import PaddleOCR

        OCR_ENGINE = PaddleOCR(
            use_angle_cls=True,
            lang="en",
            show_log=False,
        )
        logger.info("PaddleOCR engine initialised successfully.")
    except Exception as exc:  # pragma: no cover - startup failure path
        logger.exception("Failed to initialise PaddleOCR engine: %s", exc)
        OCR_ENGINE = None
    yield
    logger.info("Shutting down AI service.")


app = FastAPI(
    title="SecureChain DMS - AI Service",
    description="OCR extraction & legal document classification microservice",
    version="1.0.0",
    lifespan=lifespan,
)

# --------------------------------------------------------------------------
# Domain constants: classification, sensitivity & quorum rules
# --------------------------------------------------------------------------

DOCUMENT_TYPES = [
    "FIR",
    "Chargesheet",
    "Forensic Report",
    "Witness Statement",
    "Case Diary",
    "Internal Progress Note",
]

# Keyword banks used for scoring each candidate document type against the
# extracted OCR text. Weighted so that strong / unambiguous phrases score
# higher than generic ones.
DOCUMENT_TYPE_KEYWORDS: Dict[str, List[Tuple[str, float]]] = {
    "FIR": [
        ("first information report", 3.0),
        ("fir no", 2.5),
        ("f.i.r", 2.5),
        ("fir number", 2.0),
        ("police station", 1.0),
        ("under section", 0.5),
        ("complainant", 0.5),
    ],
    "Chargesheet": [
        ("chargesheet", 3.0),
        ("charge sheet", 3.0),
        ("final report under section 173", 3.0),
        ("section 173", 2.0),
        ("charge-sheet", 3.0),
        ("investigating officer", 0.5),
    ],
    "Forensic Report": [
        ("forensic science laboratory", 3.0),
        ("forensic report", 3.0),
        ("fsl report", 2.5),
        ("ballistic", 2.0),
        ("ballistics", 2.0),
        ("post-mortem", 2.0),
        ("postmortem", 2.0),
        ("dna profiling", 2.5),
        ("dna analysis", 2.0),
        ("viscera report", 2.0),
        ("forensic", 1.0),
    ],
    "Witness Statement": [
        ("statement of witness", 3.0),
        ("witness statement", 3.0),
        ("section 161", 2.0),
        ("deposition", 1.5),
        ("recorded statement", 1.0),
        ("i state as follows", 1.0),
    ],
    "Case Diary": [
        ("case diary", 3.0),
        ("daily diary", 2.5),
        ("cd entry", 2.0),
        ("station diary", 1.5),
        ("general diary", 1.5),
    ],
    "Internal Progress Note": [
        ("progress note", 2.5),
        ("internal note", 2.5),
        ("office note", 2.0),
        ("dispatch slip", 2.0),
        ("dispatch", 1.0),
        ("inter-office memo", 1.5),
        ("for internal circulation", 1.5),
    ],
}

# Base sensitivity tier assigned strictly by document type.
DOCUMENT_TYPE_SENSITIVITY: Dict[str, str] = {
    "FIR": "HIGH",
    "Chargesheet": "HIGH",
    "Forensic Report": "HIGH",
    "Witness Statement": "MEDIUM",
    "Case Diary": "MEDIUM",
    "Internal Progress Note": "LOW",
}

# Sensitive-content keyword bank used purely for detection/escalation signal.
SENSITIVITY_KEYWORDS = [
    "post-mortem",
    "postmortem",
    "ballistics",
    "ballistic",
    "confidential",
    "dna",
    "forensic",
    "top secret",
    "classified",
]

# Quorum matrix — strict, per the SecureChain DMS governance policy.
QUORUM_MATRIX: Dict[str, Dict[str, int]] = {
    "LOW": {"required": 1, "pool_size": 1},
    "MEDIUM": {"required": 2, "pool_size": 3},
    "HIGH": {"required": 3, "pool_size": 5},
}

TIER_ORDER = ["LOW", "MEDIUM", "HIGH"]

# Legal section reference patterns: "IPC Section 302", "Section 302 IPC",
# "BNS Section 103", "Sec. 302 IPC", "U/S 302 IPC", etc.
LEGAL_ACTS = r"(IPC|BNS|BNSS|CrPC|CPC|Evidence Act|POCSO|NDPS)"
SECTION_PATTERNS = [
    re.compile(
        rf"\b{LEGAL_ACTS}\s+(?:Section|Sec\.?|S\.)\s+(\d+[A-Za-z]*(?:\(\w+\))?)\b",
        re.IGNORECASE,
    ),
    re.compile(
        rf"\b(?:Section|Sec\.?|S\.|U/S|u/s)\s*\.?\s*(\d+[A-Za-z]*(?:\(\w+\))?)\s+(?:of\s+)?{LEGAL_ACTS}\b",
        re.IGNORECASE,
    ),
]


# --------------------------------------------------------------------------
# Pydantic response models
# --------------------------------------------------------------------------

class QuorumInfo(BaseModel):
    required: int = Field(..., description="Minimum number of approvals needed")
    pool_size: int = Field(..., description="Total size of the approver pool")


class DocumentAnalysisResponse(BaseModel):
    document_type: str = Field(..., description="Detected legal document category")
    detected_sections: List[str] = Field(
        default_factory=list, description="Legal sections referenced in the document"
    )
    sensitivity_tier: str = Field(..., description="LOW | MEDIUM | HIGH")
    recommended_quorum: QuorumInfo
    confidence_score: float = Field(
        ..., ge=0.0, le=1.0, description="Confidence of the classification, 0-1"
    )
    extracted_summary: str = Field(..., description="Short extractive summary of OCR text")
    sensitivity_keywords_found: List[str] = Field(
        default_factory=list, description="Sensitive terms detected in the document"
    )
    raw_text_char_count: int = Field(..., description="Length of full OCR text extracted")


class HealthResponse(BaseModel):
    status: str
    ocr_engine_ready: bool


# --------------------------------------------------------------------------
# OCR helpers
# --------------------------------------------------------------------------

def _pil_to_ndarray(image: Image.Image) -> np.ndarray:
    """Convert a PIL image to an RGB numpy array as expected by PaddleOCR."""
    if image.mode != "RGB":
        image = image.convert("RGB")
    return np.array(image)


def _run_ocr_on_image(image_array: np.ndarray) -> str:
    """Run PaddleOCR on a single image array and return concatenated text."""
    if OCR_ENGINE is None:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="OCR engine is not initialised. Please retry shortly.",
        )
    result = OCR_ENGINE.ocr(image_array, cls=True)
    lines: List[str] = []
    if not result:
        return ""
    # PaddleOCR returns a list per input image: [[ [box, (text, conf)], ... ]]
    for page_result in result:
        if not page_result:
            continue
        for line in page_result:
            try:
                text = line[1][0]
                if text:
                    lines.append(text)
            except (IndexError, TypeError):
                continue
    return "\n".join(lines)


def extract_text_from_upload(file_bytes: bytes, kind: str) -> str:
    """Dispatch OCR extraction depending on whether the upload is a PDF or an image."""
    all_text: List[str] = []

    if kind == "pdf":
        try:
            pages = convert_from_bytes(file_bytes, dpi=200)
        except Exception as exc:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Unable to render PDF pages: {exc}",
            )
        if not pages:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="PDF contained no renderable pages.",
            )
        for idx, page in enumerate(pages[:MAX_PDF_PAGES]):
            arr = _pil_to_ndarray(page)
            text = _run_ocr_on_image(arr)
            if text:
                all_text.append(text)
    else:  # image
        try:
            image = Image.open(io.BytesIO(file_bytes))
            image.load()
        except Exception as exc:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Unable to read image file: {exc}",
            )
        arr = _pil_to_ndarray(image)
        text = _run_ocr_on_image(arr)
        if text:
            all_text.append(text)

    return "\n".join(all_text).strip()


# --------------------------------------------------------------------------
# Classification / NLP helpers
# --------------------------------------------------------------------------

def classify_document(text: str) -> Tuple[str, float]:
    """
    Score the OCR text against each document-type keyword bank and return
    the best-matching type along with a normalised confidence score.
    """
    lowered = text.lower()

    scores: Dict[str, float] = {doc_type: 0.0 for doc_type in DOCUMENT_TYPES}
    max_possible: Dict[str, float] = {
        doc_type: sum(weight for _, weight in kws)
        for doc_type, kws in DOCUMENT_TYPE_KEYWORDS.items()
    }

    for doc_type, keyword_weights in DOCUMENT_TYPE_KEYWORDS.items():
        for phrase, weight in keyword_weights:
            if phrase in lowered:
                scores[doc_type] += weight

    best_type = max(scores, key=lambda k: scores[k])
    best_score = scores[best_type]

    if best_score <= 0:
        # No keyword signal at all — fall back to the lowest-risk default
        # and flag low confidence rather than guessing HIGH sensitivity.
        return "Internal Progress Note", 0.15

    normalised_confidence = best_score / max_possible[best_type] if max_possible[best_type] else 0.0
    # Clamp and keep a realistic floor/ceiling.
    confidence = max(0.35, min(0.99, round(normalised_confidence, 2)))
    return best_type, confidence


def detect_legal_sections(text: str) -> List[str]:
    """Extract unique legal section references, e.g. 'IPC Section 302'."""
    found: List[str] = []
    seen = set()

    for pattern in SECTION_PATTERNS:
        for match in pattern.finditer(text):
            groups = match.groups()
            # Normalise to "<ACT> Section <number>" regardless of pattern order
            if groups[0].upper() in {"IPC", "BNS", "BNSS", "CRPC", "CPC", "POCSO", "NDPS"} or groups[0].lower() == "evidence act":
                act, number = groups[0], groups[1]
            else:
                number, act = groups[0], groups[1]
            normalised = f"{act.upper()} Section {number}"
            key = normalised.lower()
            if key not in seen:
                seen.add(key)
                found.append(normalised)

    return found


def detect_sensitivity_keywords(text: str) -> List[str]:
    lowered = text.lower()
    found = [kw for kw in SENSITIVITY_KEYWORDS if kw in lowered]
    # de-duplicate while preserving order
    seen = set()
    unique = []
    for kw in found:
        if kw not in seen:
            seen.add(kw)
            unique.append(kw)
    return unique


def resolve_sensitivity_tier(document_type: str, sensitive_hits: List[str]) -> str:
    """
    Strict base rule: tier is determined by document_type per the governance
    policy. If two or more high-risk sensitivity keywords are present and the
    base tier is not already HIGH, escalate by one tier as a safety measure
    (defense-in-depth against mis-classification), never de-escalate.
    """
    base_tier = DOCUMENT_TYPE_SENSITIVITY.get(document_type, "MEDIUM")

    if len(sensitive_hits) >= 2 and base_tier != "HIGH":
        idx = TIER_ORDER.index(base_tier)
        base_tier = TIER_ORDER[min(idx + 1, len(TIER_ORDER) - 1)]

    return base_tier


def build_summary(text: str, max_sentences: int = 4, max_chars: int = 600) -> str:
    """Very lightweight extractive summary: first N sentences, capped by length."""
    if not text:
        return "No text could be extracted from the document."

    # Split on sentence-ish boundaries.
    sentences = re.split(r"(?<=[.!?])\s+", text.strip())
    sentences = [s.strip() for s in sentences if s.strip()]

    summary = " ".join(sentences[:max_sentences])
    if len(summary) > max_chars:
        summary = summary[:max_chars].rsplit(" ", 1)[0] + "..."
    if not summary:
        summary = text[:max_chars]
    return summary


# --------------------------------------------------------------------------
# Routes
# --------------------------------------------------------------------------

@app.get("/health", response_model=HealthResponse, tags=["ops"])
async def health_check() -> HealthResponse:
    return HealthResponse(status="ok", ocr_engine_ready=OCR_ENGINE is not None)


@app.post(
    "/api/v1/ai/analyze-document",
    response_model=DocumentAnalysisResponse,
    status_code=status.HTTP_200_OK,
    tags=["ai"],
)
async def analyze_document(file: UploadFile = File(...)) -> DocumentAnalysisResponse:
    """
    Accepts a PDF/JPEG/PNG document, runs OCR, classifies the document type,
    detects legal sections & sensitivity keywords, and returns the
    recommended blockchain-approval quorum.
    """
    if file.content_type not in ALLOWED_CONTENT_TYPES:
        raise HTTPException(
            status_code=status.HTTP_415_UNSUPPORTED_MEDIA_TYPE,
            detail=(
                f"Unsupported content type '{file.content_type}'. "
                f"Allowed types: {', '.join(ALLOWED_CONTENT_TYPES.keys())}"
            ),
        )

    file_bytes = await file.read()
    if not file_bytes:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Uploaded file is empty.")
    if len(file_bytes) > MAX_FILE_SIZE_BYTES:
        raise HTTPException(
            status_code=status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
            detail=f"File exceeds maximum allowed size of {MAX_FILE_SIZE_BYTES // (1024 * 1024)} MB.",
        )

    kind = ALLOWED_CONTENT_TYPES[file.content_type]

    logger.info("Received document '%s' (%s, %d bytes) for analysis", file.filename, kind, len(file_bytes))

    extracted_text = extract_text_from_upload(file_bytes, kind)

    if not extracted_text:
        logger.warning("OCR produced no text for file '%s'", file.filename)

    document_type, confidence_score = classify_document(extracted_text)
    detected_sections = detect_legal_sections(extracted_text)
    sensitivity_hits = detect_sensitivity_keywords(extracted_text)
    sensitivity_tier = resolve_sensitivity_tier(document_type, sensitivity_hits)
    quorum = QUORUM_MATRIX[sensitivity_tier]
    summary = build_summary(extracted_text)

    response = DocumentAnalysisResponse(
        document_type=document_type,
        detected_sections=detected_sections,
        sensitivity_tier=sensitivity_tier,
        recommended_quorum=QuorumInfo(required=quorum["required"], pool_size=quorum["pool_size"]),
        confidence_score=confidence_score,
        extracted_summary=summary,
        sensitivity_keywords_found=sensitivity_hits,
        raw_text_char_count=len(extracted_text),
    )

    logger.info(
        "Analysis complete: type=%s tier=%s quorum=%s confidence=%.2f",
        document_type,
        sensitivity_tier,
        quorum,
        confidence_score,
    )

    return response


@app.exception_handler(HTTPException)
async def http_exception_handler(request, exc: HTTPException):  # pragma: no cover
    return JSONResponse(status_code=exc.status_code, content={"detail": exc.detail})


if __name__ == "__main__":  # pragma: no cover
    import uvicorn

    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=False)
