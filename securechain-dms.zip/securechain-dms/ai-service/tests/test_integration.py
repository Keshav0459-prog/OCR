"""
SecureChain DMS - Integration Test Suite
=========================================

HOW TO RUN
----------
From the `ai-service/` directory, with dependencies installed
(`pip install -r requirements.txt`):

    pytest tests/ -v \
        --cov=. \
        --cov-report=term-missing \
        --cov-report=xml:coverage.xml \
        --junitxml=report.xml

This mirrors exactly what the GitLab CI `test:pytest` job runs, so a green
local run should also be green in the pipeline. The `coverage.xml` (Cobertura
format) and `report.xml` (JUnit format) are picked up by the GitLab CI
"Tests" and "Coverage" tabs automatically.

Quick run without coverage:

    pytest tests/ -v

SCOPE NOTE
----------
Test 1 exercises the real `ai-service` FastAPI app (main.py) via a mocked
OCR layer, so the suite never depends on the actual PaddleOCR model being
downloaded in CI (keeping the pipeline fast and deterministic).

Tests 2-4 exercise the maker-checker / quorum *state machine* rules that
govern the document-edit approval workflow across the wider SecureChain DMS
platform (Node.js backend + blockchain anchor layer). Since that service
lives in a separate codebase, this suite includes a small, self-contained
reference implementation (`ApprovalWorkflow`) that encodes the exact rules
specified in the SIH26190 governance policy. This lets the rules be
regression-tested here and gives the backend team an executable spec to
port/import directly into the Node.js service (or call via a shared
contract test) as that codebase matures.
"""

from __future__ import annotations

import io
import struct
import zlib
from typing import Dict, List, Optional
from unittest.mock import patch

import pytest
from fastapi.testclient import TestClient

import main as ai_main
from main import app

client = TestClient(app)


# ---------------------------------------------------------------------------
# Fixtures: dynamically generated dummy files (no external static assets)
# ---------------------------------------------------------------------------

@pytest.fixture
def tiny_png_bytes() -> bytes:
    """
    Generate a minimal, valid 1x1 white PNG entirely in-memory so the suite
    has zero dependency on files checked into the repo.
    """
    width, height = 1, 1

    def _chunk(tag: bytes, data: bytes) -> bytes:
        return (
            struct.pack(">I", len(data))
            + tag
            + data
            + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF)
        )

    sig = b"\x89PNG\r\n\x1a\n"
    ihdr = struct.pack(">IIBBBBB", width, height, 8, 2, 0, 0, 0)  # 8-bit RGB
    raw_row = b"\x00" + b"\xff\xff\xff"  # filter byte + 1 white RGB pixel
    idat = zlib.compress(raw_row)
    png = sig + _chunk(b"IHDR", ihdr) + _chunk(b"IDAT", idat) + _chunk(b"IEND", b"")
    return png


@pytest.fixture
def tiny_pdf_bytes() -> bytes:
    """
    Generate a minimal, syntactically valid single-page PDF entirely
    in-memory (no external static fixture files required).
    """
    pdf = (
        b"%PDF-1.4\n"
        b"1 0 obj<</Type/Catalog/Pages 2 0 R>>endobj\n"
        b"2 0 obj<</Type/Pages/Kids[3 0 R]/Count 1>>endobj\n"
        b"3 0 obj<</Type/Page/Parent 2 0 R/MediaBox[0 0 200 200]>>endobj\n"
        b"xref\n0 4\n"
        b"0000000000 65535 f \n"
        b"0000000009 00000 n \n"
        b"0000000052 00000 n \n"
        b"0000000101 00000 n \n"
        b"trailer<</Size 4/Root 1 0 R>>\n"
        b"startxref\n164\n"
        b"%%EOF"
    )
    return pdf


@pytest.fixture
def mock_ocr_text():
    """Factory fixture: patches the OCR extraction layer to return fixed text."""

    def _apply(text: str):
        return patch.object(ai_main, "extract_text_from_upload", return_value=text)

    return _apply


# ---------------------------------------------------------------------------
# TEST 1 — AI Classification Validation
# ---------------------------------------------------------------------------

class TestAIClassification:
    def test_high_sensitivity_chargesheet_forensic_bns(self, mock_ocr_text, tiny_pdf_bytes):
        """
        A Chargesheet referencing a BNS section plus forensic ballistics
        content must be classified HIGH sensitivity with a 3-of-5 quorum.
        """
        ocr_text = (
            "CHARGESHEET\n"
            "Final Report under Section 173 CrPC\n"
            "The accused is charged under BNS Section 103 for the offence "
            "of murder. Attached herewith is the Forensic Science Laboratory "
            "Ballistics Report confirming the recovered weapon matches the "
            "cartridge cases recovered from the scene."
        )

        with mock_ocr_text(ocr_text):
            response = client.post(
                "/api/v1/ai/analyze-document",
                files={"file": ("chargesheet.pdf", tiny_pdf_bytes, "application/pdf")},
            )

        assert response.status_code == 200
        body = response.json()

        assert body["sensitivity_tier"] == "HIGH"
        assert body["recommended_quorum"]["required"] == 3
        assert body["recommended_quorum"]["pool_size"] == 5
        assert body["document_type"] in {"Chargesheet", "Forensic Report"}
        assert "BNS Section 103" in body["detected_sections"]
        assert body["confidence_score"] > 0.0

    def test_low_sensitivity_internal_note(self, mock_ocr_text, tiny_png_bytes):
        """An internal dispatch/progress note must resolve to LOW / 1-of-1."""
        ocr_text = "INTERNAL PROGRESS NOTE\nFor internal circulation only. Dispatch slip attached."

        with mock_ocr_text(ocr_text):
            response = client.post(
                "/api/v1/ai/analyze-document",
                files={"file": ("note.png", tiny_png_bytes, "image/png")},
            )

        assert response.status_code == 200
        body = response.json()
        assert body["sensitivity_tier"] == "LOW"
        assert body["recommended_quorum"] == {"required": 1, "pool_size": 1}

    def test_medium_sensitivity_witness_statement(self, mock_ocr_text, tiny_png_bytes):
        """A witness statement must resolve to MEDIUM / 2-of-3."""
        ocr_text = "STATEMENT OF WITNESS recorded under Section 161 CrPC."

        with mock_ocr_text(ocr_text):
            response = client.post(
                "/api/v1/ai/analyze-document",
                files={"file": ("witness.png", tiny_png_bytes, "image/png")},
            )

        assert response.status_code == 200
        body = response.json()
        assert body["sensitivity_tier"] == "MEDIUM"
        assert body["recommended_quorum"] == {"required": 2, "pool_size": 3}

    def test_rejects_unsupported_content_type(self, tiny_png_bytes):
        response = client.post(
            "/api/v1/ai/analyze-document",
            files={"file": ("note.txt", b"plain text", "text/plain")},
        )
        assert response.status_code == 415

    def test_rejects_empty_file(self):
        response = client.post(
            "/api/v1/ai/analyze-document",
            files={"file": ("empty.png", b"", "image/png")},
        )
        assert response.status_code == 400


# ---------------------------------------------------------------------------
# Reference implementation of the maker-checker / quorum state machine.
# Encodes the SIH26190 governance rules under test in cases 2-4.
# ---------------------------------------------------------------------------

class WorkflowError(Exception):
    pass


class ApprovalWorkflow:
    """
    Minimal reference state machine for the document edit-approval workflow.

    States: ACTIVE -> PENDING QUORUM -> APPROVED - v{n}
    """

    def __init__(self, document_id: str, base_version: str, quorum_required: int, requester_id: str):
        self.document_id = document_id
        self.original_hash = f"hash::{document_id}::{base_version}"
        self.current_version = base_version
        self.quorum_required = quorum_required
        self.requester_id = requester_id
        self.state = "ACTIVE"
        self.approvals: List[str] = []
        self._edit_initiated = False

    def initiate_edit(self) -> None:
        """Instant-flagging rule: initiating an edit immediately moves the
        document to PENDING QUORUM without mutating the original hash."""
        self._edit_initiated = True
        self.state = "PENDING QUORUM"
        # original_hash and current_version are intentionally untouched here;
        # they only change once quorum is met (see _finalize_approval).

    def submit_approval(self, approver_id: str) -> None:
        if not self._edit_initiated:
            raise WorkflowError("No edit is currently pending approval.")

        # Maker-Checker rule: the requester may never approve their own edit.
        if approver_id == self.requester_id:
            raise WorkflowError("SELF_APPROVAL_FORBIDDEN")

        if approver_id in self.approvals:
            raise WorkflowError("DUPLICATE_APPROVAL_FORBIDDEN")

        self.approvals.append(approver_id)

        if len(self.approvals) >= self.quorum_required:
            self._finalize_approval()

    def _finalize_approval(self) -> None:
        major, minor = self.current_version.lstrip("v").split(".")
        new_version = f"v{major}.{int(minor) + 1}"
        self.current_version = new_version
        self.state = f"APPROVED - {new_version}"


# ---------------------------------------------------------------------------
# TEST 2 — Self-Approval Block (Maker-Checker Rule)
# ---------------------------------------------------------------------------

class TestMakerCheckerRule:
    def test_requester_cannot_approve_own_edit(self):
        workflow = ApprovalWorkflow(
            document_id="DOC-001",
            base_version="v1.0",
            quorum_required=3,
            requester_id="officer_raj",
        )
        workflow.initiate_edit()

        with pytest.raises(WorkflowError) as exc_info:
            workflow.submit_approval("officer_raj")

        assert "SELF_APPROVAL_FORBIDDEN" in str(exc_info.value)

    def test_self_approval_block_via_api_contract(self):
        """
        Contract-level assertion for the HTTP layer: the backend must map a
        self-approval attempt to HTTP 403. Modelled here as the expected
        status code the Node.js `/api/v1/edits/{id}/approve` endpoint must
        return, verified against the reference state machine's error code.
        """
        workflow = ApprovalWorkflow("DOC-002", "v1.0", quorum_required=3, requester_id="officer_priya")
        workflow.initiate_edit()

        def approve_endpoint(approver_id: str) -> int:
            try:
                workflow.submit_approval(approver_id)
                return 200
            except WorkflowError as e:
                return 403 if "SELF_APPROVAL_FORBIDDEN" in str(e) else 400

        status_code = approve_endpoint("officer_priya")
        assert status_code == 403


# ---------------------------------------------------------------------------
# TEST 3 — Instant-Flagging Rule
# ---------------------------------------------------------------------------

class TestInstantFlaggingRule:
    def test_edit_initiation_flags_pending_without_altering_hash(self):
        workflow = ApprovalWorkflow(
            document_id="DOC-003",
            base_version="v1.0",
            quorum_required=3,
            requester_id="officer_raj",
        )
        original_hash_before = workflow.original_hash
        original_version_before = workflow.current_version

        assert workflow.state == "ACTIVE"

        workflow.initiate_edit()

        assert workflow.state == "PENDING QUORUM"
        # The original v1.0 hash must remain untouched until quorum is met.
        assert workflow.original_hash == original_hash_before
        assert workflow.current_version == original_version_before == "v1.0"


# ---------------------------------------------------------------------------
# TEST 4 — 3-of-5 Quorum Threshold State Machine
# ---------------------------------------------------------------------------

class TestQuorumThreshold:
    def test_two_approvals_remain_pending(self):
        workflow = ApprovalWorkflow("DOC-004", "v1.0", quorum_required=3, requester_id="officer_raj")
        workflow.initiate_edit()

        workflow.submit_approval("approver_1")
        workflow.submit_approval("approver_2")

        assert workflow.state == "PENDING QUORUM"
        assert workflow.current_version == "v1.0"

    def test_third_independent_approval_transitions_to_approved(self):
        workflow = ApprovalWorkflow("DOC-004", "v1.0", quorum_required=3, requester_id="officer_raj")
        workflow.initiate_edit()

        workflow.submit_approval("approver_1")
        workflow.submit_approval("approver_2")
        assert workflow.state == "PENDING QUORUM"

        workflow.submit_approval("approver_3")

        assert workflow.state == "APPROVED - v1.1"
        assert workflow.current_version == "v1.1"

    def test_duplicate_approver_is_rejected(self):
        workflow = ApprovalWorkflow("DOC-005", "v1.0", quorum_required=3, requester_id="officer_raj")
        workflow.initiate_edit()
        workflow.submit_approval("approver_1")

        with pytest.raises(WorkflowError) as exc_info:
            workflow.submit_approval("approver_1")

        assert "DUPLICATE_APPROVAL_FORBIDDEN" in str(exc_info.value)
        assert workflow.state == "PENDING QUORUM"

    def test_quorum_matches_high_sensitivity_matrix_from_ai_service(self):
        """
        Cross-check: the quorum_required used by the workflow for a
        HIGH-sensitivity document must equal the value the AI service
        recommends (3-of-5), keeping both layers of the system consistent.
        """
        assert ai_main.QUORUM_MATRIX["HIGH"] == {"required": 3, "pool_size": 5}
        assert ai_main.QUORUM_MATRIX["MEDIUM"] == {"required": 2, "pool_size": 3}
        assert ai_main.QUORUM_MATRIX["LOW"] == {"required": 1, "pool_size": 1}
